package AffichageGeneral;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import Tools.Parser;
import AffichageBriandais.panelBriandais;
import BriandaisTree.AjoutTexteLong;
import BriandaisTree.TreeBriandais;


public class MainFrame extends JFrame implements ActionListener {
	int hauteur, largeur ;
	private GridBagConstraints gbc ;
	private JPanel Options, Rendu ;
	private JTabbedPane Arbres ;
	private ArrayList<TreeBriandais> Briandais ;
	private PanelChoixArbre Choix ;
	private PanelAjout Ajout ;
	private PanelOption Stat ;
	private PanelText Console ;

	//private TreeBriandais th = new TreeBriandais();
	private JButton Launch, Importer, image; 
	int Mode ;
	String text ;

	public MainFrame(){
		
		MiseEnPlace();
		Briandais = new ArrayList<TreeBriandais>();
		Listener();


	}

	private void Listener() {
		Launch = Ajout.getGo();
		Launch.addActionListener(this);
		Importer = Choix.GetImort();
		Importer.addActionListener(this);
	}

	private void MiseEnPlace(){
		setTitle("Algav 2014");
		setLayout(new GridBagLayout());
		gbc = new GridBagConstraints();



		GetEnvironementGraphique();
		TreeBriandais th = new TreeBriandais();
		
		setVisible(true);

		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e){
				int reponse = JOptionPane.showConfirmDialog(new JFrame(),
						"Voulez-vous quitter l'application ?",
						"Confirmation",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE);
				if (reponse==JOptionPane.YES_OPTION){
					quit();								
				}
			}
		});
		gbc.insets = new Insets(0,0,0,0);
		gbc.gridx = 0;
		gbc.gridy = 0;

		add(AjoutOption(),gbc);
		gbc.gridx = 1;
		gbc.gridy = 0;
		add(PanelArbre(),gbc);
		th.AjouterMot("test");



		invalidate();
		validate();
		repaint();
		pack();
	}


	public JPanel AjoutOption(){
		Options = new JPanel();
		Options.setLayout(new BoxLayout(Options,BoxLayout.Y_AXIS)) ;
		Options.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(Color.BLACK , Color.BLACK), "Options" , 2 ,0, new Font("Dialog", 3, 13), Color.BLACK));
		Stat = new PanelOption(500, 200);
		Console = new PanelText();
		Choix = new PanelChoixArbre();
		Ajout=new PanelAjout();
		Options.add(Choix);
		Options.add(Stat);
		Options.add(Ajout);
		Options.add(Console);

		return Options ;
	}

	public JPanel PanelArbre(){

		Arbres = new JTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT);

		ChangeListener changeListener = new ChangeListener() {

			public void stateChanged(ChangeEvent changeEvent) {
				JTabbedPane sourceTabbedPane = (JTabbedPane) changeEvent.getSource();
				int index = sourceTabbedPane.getSelectedIndex();

				if(sourceTabbedPane.getTitleAt(index).equals("Acceuil")){
					Stat.SetStat(0, 0, 0, 0,0,0);
				}
				else{
					int numBri =0 ;
					int numHy =0 ;

					for(int i=1 ; i<=Arbres.getSelectedIndex();i++){
						if(Arbres.getTitleAt(i).charAt(0) == 'B'){
							numBri++;
						}
						else{
							numHy++;
						}
					}
					if(Arbres.getTitleAt(Arbres.getSelectedIndex()).charAt(0) == 'B'){
						TreeBriandais th = Briandais.get(numBri-1);							
						MiseAJourStat(th);
					}

					else{
						//Hybrid stats
					}
				}
			}
		};
		Arbres.addChangeListener(changeListener);

		Rendu = new JPanel();
		image = new JButton("");
		image.setPreferredSize(new Dimension(800,730));

		image.setMargin(new Insets(0,0,0,0));
		image.setBorderPainted(false);
		image.setIcon(new ImageIcon(MainFrame.class.getResource("Algav.jpg" )));
		Arbres.add("Acceuil",image);
		Rendu.add(Arbres);
		Rendu.setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(Color.BLACK , Color.BLUE), "Affichage Arbre" , 2 ,0, new Font("Dialog", 3, 13), Color.BLACK));
		return Rendu;
	}

	private void GetEnvironementGraphique(){
		String lookAndFeelName = UIManager.getSystemLookAndFeelClassName();
		try {
			UIManager.setLookAndFeel(lookAndFeelName);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			e.printStackTrace();
		}
	}

	public void quit(){
		System.exit(0);
	}

	public PanelText getConsole(){
		return Console;
	}
	
	public void MiseAJourStat(TreeBriandais th){
		Stat.SetStat(th.NombreMot(), th.comptageNil(), th.hauteur(), th.profondeurMoyenne(),th.getTemps(),th.getTempslast());
	}

	public void actionPerformed(ActionEvent e) {

		if(e.getSource()==Launch){
			int numBri =0 ;
			int numHy =0 ;

			for(int i=1 ; i<=Arbres.getSelectedIndex();i++){
				if(Arbres.getTitleAt(i).charAt(0) == 'B'){
					numBri++;
				}
				else{
					numHy++;
				}
			}

			if(!Ajout.getMot().equals("")){
				
				
				if(Briandais.isEmpty() /* && Hybrid.isempty() ) */ || Arbres.getSelectedIndex()==0 && Ajout.getMode()==1){
					Console.setText("\n***** Ajout de mot sur un arbre nouveau *****");
					TreeBriandais th = new TreeBriandais();
					Briandais.add(th);
					th.setConsole(Console);
					String mot = Ajout.getMot()+" ";
					th.ajoutPhrase(mot,false);
					MiseAJourStat(th);
					panelBriandais test = new panelBriandais(th,th.NombreMot() );
					Arbres.add("Briandais n°"+Briandais.size(),test.getArbre());
					Arbres.setSelectedIndex(Arbres.getTabCount()-1);

				}
				else{

					if(Arbres.getTitleAt(Arbres.getSelectedIndex()).charAt(0) == 'B'){

						if(Ajout.getMode()==1){ // mode ajout mot
							Console.setText("\n***** Ajout de mot *****");
							TreeBriandais th = Briandais.get(numBri-1);
							String mot = Ajout.getMot()+" ";
							th.ajoutPhrase(mot,false);
							MiseAJourStat(th);
							panelBriandais test = new panelBriandais(th,th.NombreMot() );
							Arbres.setComponentAt(Arbres.getSelectedIndex(), test.getArbre());
							Console.setText("ok2");
						}
						else if (Ajout.getMode()==2){ //mode rechercher mot
							TreeBriandais th = Briandais.get(numBri-1);
							Console.setText("\n***** Recherche de mot *****");
							int a = th.findString(Ajout.getMot() , false);
							if(a == -1){
								Console.setText(Ajout.getMot() +" n'est pas présent ");
							}



						}
						else{ //mode supprimer mot
							TreeBriandais th = Briandais.get(numBri-1);
							Console.setText("\n***** Suppression de mot *****");
							th.suppression(Ajout.getMot());




						}
					}
					else{
						Console.setText("Aucun arbre selectionné");
						//Action sur arbre Hybride n° numHy de la liste des Hybrides.

					}



				}





				Ajout.ResetMot();
				Rendu.updateUI();
				pack();
				setResizable(false);

			}else{
				if(Ajout.getMode()==4){


					if(Arbres.getTitleAt(Arbres.getSelectedIndex()).charAt(0) == 'B'){ //liste Mot Briandais
						TreeBriandais th = Briandais.get(numBri-1);
						Console.setText("\n***** Liste des mots par ordre alphabetique *****");
						for(String mot : th.listeMots()  ){
							Console.setText(mot);
						}
					}
					else{   //liste Mot Hybrid
						Console.setText("Aucun arbre selectionné");
					}

				}
				else
					Console.setText("commande ou mot invalide");
			}

		}

		if(e.getSource()==Importer){

			JFileChooser choixText = new JFileChooser();

			int openAction = choixText.showOpenDialog(Choix);

			if (openAction == JFileChooser.APPROVE_OPTION) {
				ChargeText(choixText.getSelectedFile());
				repaint();
			}		
			Rendu.updateUI();
			pack();
			setResizable(false);
		}
	}//fin listener

	public void AjoutText(String mot){
		if(Choix.GetMode()==1){ // creer arbre Briandais
			System.out.println("mode thread");
			TreeBriandais th = new TreeBriandais();
			Briandais.add(th);
			th.setConsole(Console);
			th.setChoix(Choix);
			mot = mot+" ";
			AjoutTexteLong test1 = new AjoutTexteLong(mot, th, Arbres,Briandais.size());
			test1.start();
		    //th.ajoutPhrase(mot);
			//th=(TreeBriandais) test1.get();
			}
		
		else if(Choix.GetMode()==2){ //creer arbre Hybrid

		}
		else{ // creer 2 arbres

			TreeBriandais th = new TreeBriandais();
			Briandais.add(th);
			th.setConsole(Console);
			mot = mot+" ";
		//	th.ajoutPhrase(mot);
			panelBriandais test = new panelBriandais(th,th.NombreMot() );
			Arbres.add("Briandais n°"+Briandais.size(),test.getArbre());
			Arbres.setSelectedIndex(Arbres.getTabCount()-1);


		}

	}

	public void ChargeText(File TextFile) {
		String Texte="";
		try{
			InputStream ips=new FileInputStream(TextFile); 
			InputStreamReader ipsr=new InputStreamReader(ips);
			BufferedReader br=new BufferedReader(ipsr);
			String ligne;

			while ((ligne=br.readLine())!=null){
				Texte+=ligne+" ";
			}
			br.close();
			AjoutText(Texte);
			System.out.println("texte chargé");
		}		
		catch (Exception e){
			System.out.println(e.toString());
		}

	}



}
