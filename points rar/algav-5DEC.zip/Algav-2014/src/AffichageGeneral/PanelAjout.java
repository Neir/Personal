package AffichageGeneral;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTextField;



public class PanelAjout extends JPanel {

	private JCheckBox ajouter , rechercher , supprimer, ListeMot ;
	private JTextField Mot ;
	private JButton go ;
	private GridBagConstraints gbc ;
	int Mode=1 ;
	public PanelAjout(){
		MiseEnPlace();
	}
	private void MiseEnPlace() {
		JPanel Mode = new JPanel();
		Mode.setLayout(new GridBagLayout());
		gbc = new GridBagConstraints();

		ajouter = new JCheckBox("Ajouter");
		rechercher = new JCheckBox("Rechercher");
		supprimer = new JCheckBox("Supprimer");
		ListeMot = new JCheckBox("Lister les mots");
		
		ajouter.addActionListener(new CheckBoxAction());
		rechercher.addActionListener(new CheckBoxAction());
		supprimer.addActionListener(new CheckBoxAction());
		ListeMot.addActionListener(new CheckBoxAction());
		
		gbc.gridwidth = 1;
		gbc.gridheight = 1;
		gbc.insets = new Insets(0,30,0,0);
		gbc.gridx = 0;
		gbc.gridy = 0;

		Mode.add(ajouter,gbc);
		gbc.insets = new Insets(0,0,0,0);
		gbc.gridx = 1;
		Mode.add(rechercher,gbc);
		gbc.gridx = 2;
		Mode.add(ListeMot,gbc);
		gbc.gridx = 3;
		gbc.insets = new Insets(0,0,0,30);
		Mode.add(supprimer,gbc);
		ajouter.setSelected(true);
		
		
		Mot=new JTextField();
		Mot.setPreferredSize(new Dimension(200, 20));
		gbc.gridwidth = 4;
		gbc.gridheight = 1;
		gbc.insets = new Insets(0,0,0,0);
		gbc.gridx = 0;
		gbc.gridy = 1;
		Mode.add(Mot,gbc);
		go = new JButton("lancer");
		go.setPreferredSize(new Dimension(120, 25));
		gbc.gridwidth = 2;
		gbc.gridx = 1;
		gbc.gridy = 2;
		Mode.add(go,gbc);
		add(Mode);

		setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(Color.BLACK , Color.BLUE), "Modification de l'arbre affiché" , 2 ,0, new Font("Dialog", 3, 13), Color.BLACK));
	}
	public String getMot() {
		return Mot.getText();
	}
	public void ResetMot() {
		Mot.setText("");
	}
	public int getMode() {
		return Mode;
	}

	public JButton getGo() {
		return go;
	}
	
	
	


	class CheckBoxAction implements ActionListener{
		public void actionPerformed(ActionEvent e) {

			JCheckBox p = (JCheckBox) e.getSource() ;
			if(p.getLabel() == "Ajouter" ){
				Mode=1;
				if(rechercher.isSelected()){rechercher.setSelected(false);}
				if(supprimer.isSelected()){supprimer.setSelected(false);}
				if(ListeMot.isSelected()){
					ListeMot.setSelected(false);
					Mot.setEnabled(true);
				}
			}
			
			if(p.getLabel() == "Lister les mots" ){
				Mode=4;
				if(rechercher.isSelected()){rechercher.setSelected(false);}
				if(supprimer.isSelected()){supprimer.setSelected(false);}
				if(ajouter.isSelected()){ajouter.setSelected(false);}
				Mot.setText("");Mot.setEnabled(false);
			}

			if(p.getLabel() == "Rechercher" ){
				Mode=2;
				if(ajouter.isSelected()){ajouter.setSelected(false);}
				if(supprimer.isSelected()){supprimer.setSelected(false);}
				if(ListeMot.isSelected()){
					ListeMot.setSelected(false);
					Mot.setEnabled(true);
				}
			}
			if(p.getLabel() == "Supprimer" ){
				Mode=3;
				if(ajouter.isSelected()){ajouter.setSelected(false);}
				if(rechercher.isSelected()){rechercher.setSelected(false);}
				if(ListeMot.isSelected()){
					ListeMot.setSelected(false);
					Mot.setEnabled(true);
				}

			}

		}
	}
}

