package TrieHybride;
import java.util.ArrayList;

import Tools.Parser;
import BriandaisTree.NoeudBin;
import BriandaisTree.TreeBriandais;


public class TrieHybride {
	private Noeud racine;
	private int nb_mot;
	
	public TrieHybride(){
		racine = new Noeud();
		nb_mot = 0;
	}
	
	public boolean recherche(String mot){
		return navigue(racine, mot.toCharArray(), 0);
	}

	private boolean navigue(Noeud currentNode, char[] mot, int i) {
		if(currentNode.estNil() || currentNode == null)
			return false;
		else if(mot[i]<currentNode.getEtiquette())
			return navigue(currentNode.getInf(), mot, i);
		else if(mot[i]>currentNode.getEtiquette())
			return navigue(currentNode.getSup(), mot, i);
		else //  mot[i] == currentNode.getEtiquette()
			if(mot.length-1 == i)
				return (currentNode.getId() >= 0)? true : false;
			else
				return navigue(currentNode.getEq(), mot, i+1);
	}

	public void ajoutMot(String mot){
		navigueAjout(racine, mot.toCharArray(), 0);
	}

	private void navigueAjout(Noeud currentNode, char[] mot, int i) {
		if(i != mot.length){
			if(currentNode.estNil()){
				currentNode.setEtiquette(mot[i]);
				//currentNode.setEtiquette(mot[i]);
				if(i == mot.length-1){ 	
					//System.out.println("Etiquette ! "+currentNode.getEtiquette()+"      taille : "+mot.length+"     mot : "+String.valueOf(mot));
					currentNode.setId(nb_mot++);
				} else {
					navigueAjout(currentNode.getEq(), mot, i+1);
				}
			} else if(mot[i]<currentNode.getEtiquette()){
				navigueAjout(currentNode.getInf(), mot, i);
			} else if(mot[i]>currentNode.getEtiquette()){
				navigueAjout(currentNode.getSup(), mot, i);
			} else //  mot[i] == currentNode.getEtiquette()
				navigueAjout(currentNode.getEq(), mot, i+1);
		}
	}
	
	public void ajoutListeMot(ArrayList<String> listeMot){
		for(String mot : listeMot)
			this.ajoutMot(mot);
	}
	
	public void ajoutPhrase(String phrase){
		for(String mot : Parser.parseBufferToWords(phrase))
			this.ajoutMot(mot);
	}

	public int comptageMots(){
		return nb_mot;
	}
	
	public ArrayList<String> listeMots(){
		return navigueListeMots(racine, "");
	}
	
	private ArrayList<String> navigueListeMots(Noeud currentNode, String prefixeMot){
		String nouveauMot = prefixeMot;
		//nouveauMot.concat(String.valueOf(currentNode.getEtiquette()));
		nouveauMot += currentNode.getEtiquette();
		ArrayList<String> result = new ArrayList<String>();
		
		//System.out.println("Etiquette ! "+currentNode.getEtiquette()+"      prefixe : "+prefixeMot+"      mot : "+nouveauMot);
		
		if(currentNode.estNil()) return null;
		
		if(currentNode.getId()>=0){		//System.out.println("PASSE LA ! "+nouveauMot+"    id = "+currentNode.getId());
			result.add(nouveauMot);
		}
		if(!currentNode.getInf().estNil()) result.addAll(navigueListeMots(currentNode.getInf(), prefixeMot));
		if(!currentNode.getEq().estNil()) result.addAll(navigueListeMots(currentNode.getEq(), nouveauMot));
		if(!currentNode.getSup().estNil()) result.addAll(navigueListeMots(currentNode.getSup(), prefixeMot));
		return result;
	}
	
	public int comptageNil(){
		return navigueNil(racine);
	}
	
	private int navigueNil(Noeud currentNode) {
		if(currentNode.estNil()){
			return 1;
		} else
			//if(mot[i]<currentNode.getEtiquette()){
			return navigueNil(currentNode.getInf()) +
					navigueNil(currentNode.getEq()) +
					navigueNil(currentNode.getSup());
	}
	
	public int hauteur(){
		return navigueHauteur(racine);
	}

	private int navigueHauteur(Noeud currentNode) {
		if(currentNode == null){
			return 0;
		} else
			return 1 + Math.max(Math.max(navigueHauteur(currentNode.getInf()),
					navigueHauteur(currentNode.getEq())),
					navigueHauteur(currentNode.getSup()));
	}
	
	public int profondeurMoyenne(){
		int somme = 0;
		ArrayList<Integer> profondeurs = new ArrayList<Integer>();
		
		navigueProfondeur(racine.getInf(), profondeurs, 1);
		navigueProfondeur(racine.getEq(), profondeurs, 1); 
		navigueProfondeur(racine.getSup(), profondeurs, 1); 
		
		for(Integer prof : profondeurs){
			//System.out.println("    Profondeur : "+prof);
			somme += (int) prof;
		}
		return somme/profondeurs.size();
	}
	
	private void navigueProfondeur(Noeud currentNode, ArrayList<Integer> listProfs, int currentp){
		if(currentNode.estNil()){
			return;
		} else if(currentNode.estFeuille()){
			listProfs.add(currentp);
		} else {
			navigueProfondeur(currentNode.getInf(), listProfs, currentp+1);
			
			navigueProfondeur(currentNode.getEq(), listProfs, currentp+1);
			
			navigueProfondeur(currentNode.getSup(), listProfs, currentp+1);
		}
	}

	public int prefixe(String mot){
		return naviguePrefixe(racine, mot.toCharArray(), 0);
	}

	private int naviguePrefixe(Noeud currentNode, char[] mot, int i) {
		if(currentNode.estNil() || currentNode == null)
			return 0;

		if(mot.length > i){
			if(mot[i]<currentNode.getEtiquette())
				return naviguePrefixe(currentNode.getInf(), mot, i);
			else if(mot[i]>currentNode.getEtiquette())
				return naviguePrefixe(currentNode.getSup(), mot, i);
			else {//  mot[i] == currentNode.getEtiquette()
				if(mot.length-1 == i && currentNode.getId() != -1) // le prefixe est un mot
					return 1 + naviguePrefixe(currentNode.getEq(), mot, i+1);
				return naviguePrefixe(currentNode.getEq(), mot, i+1);
			}
		} else { // On a trouv� le prefixe
			if(currentNode.getId() != -1) // le noeud contient un mot
				return 1 + naviguePrefixe(currentNode.getInf(), mot, i) 
						+ naviguePrefixe(currentNode.getEq(), mot, i)
						+ naviguePrefixe(currentNode.getSup(), mot, i);
			else
				return naviguePrefixe(currentNode.getInf(), mot, i) 
						+ naviguePrefixe(currentNode.getEq(), mot, i)
						+ naviguePrefixe(currentNode.getSup(), mot, i);
		}
	}

	public void suppression(String mot){
		if(recherche(mot)){
			navigueSuppr(racine, mot.toCharArray());
		}
	}
	
	private void navigueSuppr(Noeud node, char[] mot){
		Noeud currentNode = node;
		Noeud noeudCle = null; 
		int oldfils = -2; // -1 = inf, 0 = eq, 1 = sup, -2 = rien � supprimer
		int i = 0;
		while(i<mot.length){
			if(mot[i]<currentNode.getEtiquette()){
				currentNode = currentNode.getInf();
				noeudCle = currentNode; oldfils = -1;
			} else if (mot[i]<currentNode.getEtiquette()){
				currentNode = currentNode.getSup();
				noeudCle = currentNode; oldfils = 1;
			} else {
				if(currentNode.estNil()){
/*					switch(newfils){
					case -1 :
						noeudCle.setEq(noeudCle.getInf().clone());
						noeudCle.getInf().setNil();
						break;
					case 0 :
						noeudCle.getEq().setNil();
						break;
					case 1 :
						noeudCle.setEq(noeudCle.getSup().clone());
						noeudCle.getSup().setNil();
						break;
					}
					//*/
					switch(oldfils){
					case -1 :
						noeudCle.getInf().supprimerRec();
						return;
					case 0 :
						noeudCle.getEq().supprimerRec();
						return;
					case 1 :
						noeudCle.getSup().supprimerRec();
						return;
					case -2 :
						return;
					}
					if(!currentNode.getInf().estNil() || !currentNode.getSup().estNil()){
						noeudCle = currentNode; oldfils = 0;
					}
				}
				if(i == mot.length-1){
					currentNode.setId(-1);
				}
				
				currentNode = currentNode.getEq();
				i++;
			}
		}
		
	}

	public TreeBriandais conversion(){
		TreeBriandais bt = new TreeBriandais();
		
	//	bt.setRacine(navigueConversion(racine));
		
		return bt;
	}
	
	private NoeudBin navigueConversion(Noeud currentNode){
		NoeudBin noeudBriandais = new NoeudBin();
		
		if(currentNode.estNil()) return null;
		
		noeudBriandais.setEtiquette(currentNode.getEtiquette());
		
		if(!currentNode.getEq().estNil())
			noeudBriandais.setDroit(navigueConversion(currentNode.getEq()));
		
		if(!currentNode.getInf().estNil())
			noeudBriandais.setGauche(navigueConversion(currentNode.getInf()));
		
		if(!currentNode.getSup().estNil())
		insereAgauche(noeudBriandais, currentNode.getSup());
		
		return noeudBriandais;
	}
	
	private void insereAgauche(NoeudBin ndB, Noeud ndH){
		NoeudBin newNd = ndB.getGauche();
		for(; newNd != null; newNd = newNd.getGauche());
		newNd = navigueConversion(ndH);
	}
	
	public Noeud getRacine() {
		return racine;
	}

	public void setRacine(Noeud racine) {
		this.racine = racine;
	}
}