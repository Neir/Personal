package TrieHybride.test;

import Tools.Affichage;
import TrieHybride.TrieHybride;

public class AffichageTest {
	public static void main(String[] args){
		TrieHybride th = new TrieHybride();
		th.ajoutPhrase("A quel genial professeur de dactylographie "
				+ "sommes nous redevable de la superbe phrase ci dessous :"
				+ "un modele du genre que toute dactylo connait par coeur "
				+ "puisque elle fait appel a chacune des touches du clavier "
				+ "de la machine a ecrire.");
		
		Affichage.printTrieHybride(th);
	}
}
