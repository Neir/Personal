package TrieHybride.test;

import TrieHybride.TrieHybride;

public class ConstructionTest {
	public static void main(String[] args){
		TrieHybride th = new TrieHybride();
		
		System.out.println("Ajout de 'loups'");
		th.ajoutMot("loups");
		
		System.out.println("Ajout de 'le'");
		th.ajoutMot("le");
		
		System.out.println("Ajout de 'lourds'");
		th.ajoutMot("lourds");
		
		System.out.println("\t   nb_mots = "+th.comptageMots());
		System.out.println("\t   nb_nils = "+th.comptageNil());
		System.out.println("\t   hauteur = "+th.hauteur());
		System.out.println("profondeur moyenne = "+th.profondeurMoyenne());
		
		System.out.println("  nombre de mot avec le prefixe 'l' = "+th.prefixe("l"));
		System.out.println("nombre de mot avec le prefixe 'lou' = "+th.prefixe("lou"));
		System.out.println(" nombre de mot avec le prefixe 'le' = "+th.prefixe("le"));
		System.out.println(" nombre de mot avec le prefixe 'yo' = "+th.prefixe("yo"));
		
		System.out.println((th.recherche("loups"))? "loups est dans l'arbre" : "\tloups n'est pas dans l'arbre");
		System.out.println((th.recherche("le"))? "le est dans l'arbre" : "\tle n'est pas dans l'arbre");
		System.out.println((th.recherche("lourds"))? "lourds est dans l'arbre" : "\tlourds n'est pas dans l'arbre");
		
		System.out.println((th.recherche("lou"))? "lou est dans l'arbre" : "\tlou n'est pas dans l'arbre");
		System.out.println((th.recherche("lourdeau"))? "lourdeau est dans l'arbre" : "\tlourdeau n'est pas dans l'arbre");

		System.out.println("Liste de mots : "+th.listeMots());
		
		System.out.println("Suppression de 'loups'");
		th.suppression("loups");
		System.out.println((th.recherche("loups"))? "loups est dans l'arbre" : "\tloups n'est pas dans l'arbre");
		
		System.out.println("Suppression de 'le'");
		th.suppression("le");
		System.out.println((th.recherche("le"))? "le est dans l'arbre" : "\tle n'est pas dans l'arbre");
		
//		System.out.println("Suppression de 'lourds'");
//		th.suppression("lourds");
//		System.out.println((th.recherche("lourds"))? "lourds est dans l'arbre" : "\tlourds n'est pas dans l'arbre");
		
		System.out.println("Liste de mots : "+th.listeMots());
		
		th.conversion();
		
	}
	
}
