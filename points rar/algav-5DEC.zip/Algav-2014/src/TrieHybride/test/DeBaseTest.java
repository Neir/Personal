package TrieHybride.test;

import TrieHybride.TrieHybride;

public class DeBaseTest {
		public static void main(String[] args){
			TrieHybride th = new TrieHybride();
			th.ajoutMot("A");
			th.ajoutMot("quel");
			th.ajoutMot("genial");
			th.ajoutMot("professeur");
			th.ajoutMot("de");
			th.ajoutMot("dactylographie");
			th.ajoutMot("sommes");
			th.ajoutMot("nous");
			th.ajoutMot("redevables");
			th.ajoutMot("de");
			th.ajoutMot("la");
			th.ajoutMot("superbe");
			th.ajoutMot("phrase");
			th.ajoutMot("ci");
			th.ajoutMot("dessous");
			th.ajoutMot("un");
			th.ajoutMot("modele");
			th.ajoutMot("du");
			th.ajoutMot("genre");
			th.ajoutMot("que");
			th.ajoutMot("toute");
			th.ajoutMot("dactylo");
			th.ajoutMot("connait");
			th.ajoutMot("par");
			th.ajoutMot("coeur");
			th.ajoutMot("puisque");
			th.ajoutMot("elle");
			th.ajoutMot("fait");
			th.ajoutMot("appel");
			th.ajoutMot("a");
			th.ajoutMot("chacune");
			th.ajoutMot("des");
			th.ajoutMot("touches");
			th.ajoutMot("du");
			th.ajoutMot("clavier");
			th.ajoutMot("de");
			th.ajoutMot("la");
			th.ajoutMot("machine");
			th.ajoutMot("a");
			th.ajoutMot("ecrire");
			/*
			th.ajoutPhrase("A quel genial professeur de dactylographie "
					+ "sommes nous redevable de la superbe phrase ci dessous :"
					+ "un modele du genre que toute dactylo connait par coeur "
					+ "puisque elle fait appel a chacune des touches du clavier "
					+ "de la machine a ecrire.");
			*/

			System.out.println("\t   nb_mots = "+th.comptageMots());
			System.out.println("\t   nb_nils = "+th.comptageNil());
			System.out.println("\t   hauteur = "+th.hauteur());
			System.out.println("profondeur moyenne = "+th.profondeurMoyenne());


			System.out.println("\nnombre de mot avec le prefixe 'dactylo' = "+th.prefixe("dactylo"));
			
			System.out.println("\nListe de mots : "+th.listeMots());
			
		}
}
