package BriandaisTree;

import javax.swing.JTabbedPane;

import AffichageBriandais.panelBriandais;
import Tools.SwingWorker;

public class AjoutTexteLong extends SwingWorker {

	String mot ;
	TreeBriandais th;
	JTabbedPane Arbres;
	int size;

	public AjoutTexteLong(String mot, TreeBriandais th, JTabbedPane arbres,int a){
		this.mot=mot;
		this.th = th ;
		this.Arbres=arbres;
		this.size=a;
		
		
	}
	public Object construct() {
		
		th.ajoutPhrase(mot,true);
		panelBriandais test = new panelBriandais(th,th.NombreMot() );
		Arbres.add("Briandais n°"+size,test.getArbre());
		Arbres.setSelectedIndex(Arbres.getTabCount()-1);
		
		return th;
	}

}
