package BriandaisTree;

import java.util.ArrayList;

import Tools.Parser;
import AffichageGeneral.PanelChoixArbre;
import AffichageGeneral.PanelText;
import BriandaisTree.Noeud;

public class TreeBriandais {

	public Noeud racine;
	private int Nbmot =0 ;
	protected char FinMot = '*';
	private PanelText console ;
	private PanelChoixArbre Progress ;
	private Noeud Pere ;
	private long temps=0, tempslast ;



	public void setTemps(long t) {
		temps = t ;
	}
	public void setTempsLast(long t){
		tempslast = t;
	}
	public long getTemps() {
		return temps;
	}
	public long getTempslast() {
		return tempslast;
	}
	public void setChoix(PanelChoixArbre Progress ){
		this.Progress=Progress;
	}
	public void setConsole(PanelText console){
		this.console=console;
	}
	public void ajoutPhrase(String phrase,boolean lon){
		if(lon)Progress.SetValueBrian(1);
		ArrayList<String> mots = Parser.parseBufferToWords(phrase);
		console.setText(mots.size()+" : mots a ajouter");
		int ratio = mots.size()/100;
		int ratioActu=0 ;
		int i=0;
		for(String mot : Parser.parseBufferToWords(phrase)){
			if(findString(mot,true)!=1){
				this.AjouterMot(mot);
				if(!lon){
					console.setText("\""+mot+"\" ajouté.");
				}
				else{
					i++;
					if(i==ratio){
						ratioActu++;
						i=0;
						Progress.SetValueBrian(ratioActu);
						//console.setText(ratioActu+"% effectué");
					}

				}
			}

			else{
				if(!lon)console.setText("\""+mot+"\" non ajouté car deja present.");
				else{
					i++;
					if(i==ratio){
						ratioActu++;
						i=0;
						Progress.SetValueBrian(ratioActu);
//						console.setText(ratioActu+"% effectué");
					}
				}
			}
		}
	}

	public void AjouterMot(String Mot){
		long start = System.nanoTime();
		Pere = racine ;
		Noeud NoeudCourant = racine ;
		char letters[] = Mot.toCharArray();
		for (char letter : letters) {

			if (racine == null) {
				racine = new Noeud( letter, null, null );
				NoeudCourant = racine;
			}
			else if(NoeudCourant.getFils()==null ){
				Pere = NoeudCourant ;
				NoeudCourant = AjouterFils(letter, NoeudCourant) ;
			}
			else if(NoeudCourant.value == letter){
				Pere = NoeudCourant ;
				NoeudCourant = NoeudCourant.getFils() ;

			}
			else{
				NoeudCourant = AjouterFrere(letter , NoeudCourant) ;
			}

		}
		if(NoeudCourant.getFils() == null){
			Nbmot++;
			NoeudCourant=AjouterFils(FinMot, NoeudCourant) ;
		}
		else{
			Nbmot++;
			NoeudCourant=AjouterFrere(FinMot, NoeudCourant) ;
		}
		long duree = System.nanoTime() - start;
		setTemps(temps+duree) ;
		setTempsLast(duree) ;
	}

	public Noeud AjouterFrere(char a, Noeud NoeudCourant){

		Noeud frere = new Noeud(a, null,null);


		//Si racine en jeu
		if(NoeudCourant == racine && a < racine.value){
			Noeud NewRacine = new Noeud(a, racine ,null);
			racine = NewRacine ;
			return racine ;

		}
		else if(NoeudCourant.getFrere() == null){ 
			if(NoeudCourant.value>a){
				Noeud temps = Pere.getFils() ;
				frere.setFrere(temps) ;
				Pere.setFils(frere) ;

			}
			else{

				NoeudCourant.setFrere(frere);
			}

			return frere ;

		}
		else{

			// premiere place ? Noeud winner ?
			if(NoeudCourant.value>a){
				Noeud temps = Pere.getFils() ;
				frere.setFrere(temps)   ;
				Pere.setFils(frere) ;
			}

			else {
				Noeud NoeudParent = NoeudCourant ;
				Noeud NoeudEnCours = NoeudCourant.getFrere() ;
				while(NoeudEnCours != null){

					if(a > NoeudEnCours.value ){
						NoeudParent = NoeudEnCours ;
						NoeudEnCours =NoeudEnCours.getFrere() ;
					}

					else if(a == NoeudEnCours.value){
						if(NoeudEnCours.getFils()==null){
							return NoeudCourant.getFrere();

						}
						else{ 
							Pere = NoeudEnCours;
							return NoeudEnCours.getFils();
						}
					}

					else{ //(a<NoeudEnCours.value)
						NoeudParent.setFrere(frere)  ;
						frere.setFrere(NoeudEnCours)  ;
						return frere ;
					}
				}
				NoeudParent.setFrere(frere)  ;

			}
		}
		return frere;
	}

	public Noeud AjouterFils(char a, Noeud NoeudCourant){
		Noeud fils = new Noeud(a, null,null);
		if(NoeudCourant.value == FinMot){
			NoeudCourant = AjouterFrere( a, NoeudCourant) ;
			return NoeudCourant ;
		}
		NoeudCourant.setFils(fils);
		return fils ;
	}


	public int findString(String word, boolean Ajout) {
		if(racine==null) return -1 ;
		else return( RechercheMot(word,0,racine,Ajout) );
	}



	// RechercheMot retourne 1 si existe, 0 si prefix, -1 sinon
	public int RechercheMot(String word, int PositionLettre, Noeud NoeudCourant, boolean Ajout) {
		int current;
		if( PositionLettre < word.length() ) {


			while(NoeudCourant.getFrere() != null) {
				if( NoeudCourant.value == word.charAt(PositionLettre) ) {
					current = RechercheMot(word,PositionLettre+1,NoeudCourant.getFils(),Ajout);

					if( current == 0 ) {
						return( 0 );
					}
					else if( current == 1 ) {
						return( 1 );
					}
					else {
						return( -1 );
					}
				}
				NoeudCourant = NoeudCourant.getFrere();
			}


			if( NoeudCourant.getFrere() == null && NoeudCourant.value == word.charAt(PositionLettre) ) {
				current = RechercheMot(word,PositionLettre+1,NoeudCourant.getFils(),Ajout);
				if( current == 0 ) {
					return( 0 );
				}
				else if( current == 1 ) {
					return( 1 );
				}
				else {
					return( -1 );
				}
			}
			else {
				return( -1 );
			}
		}
		else {
			if( NoeudCourant.value == FinMot ){
				if(!Ajout){listeMotsPrefix(NoeudCourant, word, 1);}
				return( 1 );
			}
			else{
				if(!Ajout){listeMotsPrefix(NoeudCourant, word, 0);}
				return( 0 );
			}
		}
	}
	public void SupprimerMot(){

	}

	public void suppression(String mot){
		//	if(findString(mot,true)==1|findString(mot,true)==0){
		//	navigueSuppr(racine, mot.toCharArray());
		//	}
		String prefMen="";
		String prefix ="";

		//prefix+= mot.charAt(0);
		//int a = RechercheMot(prefix, 0, racine, true);
		//System.out.println(mot.toCharArray().length+"  "+ prefix);

		for(int i=0 ; i<mot.toCharArray().length ; i++){
			int a = RechercheMot(prefix, 0, racine, true);
			if(a == 0){
				prefMen=prefix;
			}
			prefix+= mot.charAt(i);
		}


		console.setText("le plus grand prefix est :"+ prefMen);	
	}


	public int NombreMot(){
		return Nbmot;
	}

	public int comptageNil(){
		return navigueNil(racine);
	}

	private int navigueNil(Noeud currentNode) {
		if(currentNode == null){
			return 1;
		} else
			//if(mot[i]<currentNode.getEtiquette()){
			return navigueNil(currentNode.getFils()) +
					navigueNil(currentNode.getFrere());
	}

	public int profondeurMoyenne(){
		int somme = 0;
		ArrayList<Integer> profondeurs = new ArrayList<Integer>();

		navigueProfondeur(racine.getFils(), profondeurs, 2);
		navigueProfondeur(racine.getFrere(), profondeurs, 2); 

		for(Integer prof : profondeurs){
			//System.out.println("    Profondeur : "+prof);
			somme += (int) prof;
		}
		return  somme/profondeurs.size();

	}

	private void navigueProfondeur(Noeud currentNode, ArrayList<Integer> listProfs, int currentp){
		if((currentNode == null) ){
			return ;
		} else if(currentNode.getFils()== null && currentNode.getFrere()==null){
			listProfs.add(currentp);			
		} else {
			navigueProfondeur(currentNode.getFils(), listProfs, currentp+1);

			navigueProfondeur(currentNode.getFrere(), listProfs, currentp+1);			

		}
	}

	public ArrayList<String> listeMots(){
		return navigueListeMots(racine, "");
	}

	public void listeMotsPrefix(Noeud N, String prefix, int i){
		ArrayList<String> l = navigueListeMots(N, prefix);
		if(i==0){
			console.setText(prefix+" n'existe pas mais est préfixe des "+l.size()+" mot(s) suivant(s) :");
			for(String mot : l  ){
				console.setText(mot);
			}
		}
		else{
			if(l.size()==1){
				console.setText(prefix+" existe et n'est pas prefixe d'autres mots.");
			}
			else{
				console.setText(prefix+" existe et est préfixe des "+l.size()+" mot(s) suivant(s) :");
				for(String mot : l  ){
					console.setText(mot);
				}
			}
		}


	}

	private ArrayList<String> navigueListeMots(Noeud currentNode, String prefixeMot){
		String nouveauMot = prefixeMot;
		nouveauMot += currentNode.value;

		ArrayList<String> result = new ArrayList<String>();

		if(currentNode == null) return null;

		if(currentNode.value == FinMot){		//System.out.println("PASSE LA ! "+nouveauMot+"    id = "+currentNode.getId());
			result.add(nouveauMot.substring(0, nouveauMot.length() -1));
		}

		if(!(currentNode.getFils()==null)) result.addAll(navigueListeMots(currentNode.getFils(), nouveauMot));
		if(!(currentNode.getFrere()==null)) result.addAll(navigueListeMots(currentNode.getFrere(), prefixeMot));
		return result;
	}

	public int hauteur(){
		return Hauteur(racine);
	}

	public int Hauteur(Noeud Courant){
		if(Courant == null){
			return 0;
		} else
			return 1 + Math.max(Hauteur(Courant.getFrere()),Hauteur(Courant.getFils()));
	}

}
