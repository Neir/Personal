package BriandaisTree;

public class NoeudBin {
	private NoeudBin gauche; //alternative
	private NoeudBin droit;  //suivant
	private char etiquette;
	private char finMot ;
	
	public NoeudBin(){
		gauche = null ;
		droit = null ;
		etiquette = (char) -1;
		finMot = (char) -1;
	}
	
	public NoeudBin(char a){
		gauche = null ;
		droit = null ;
		etiquette = a;
		finMot = (char) -1;
	}
	
	public boolean estNil(){
		return (getEtiquette()==((char)-1));
	}

	public NoeudBin getGauche() {
		return gauche;
	}
	public void setGauche(NoeudBin gauche) {
		this.gauche = gauche;
	}
	
	public NoeudBin getDroit() {
		return droit;
	}
	
	public void setDroit(NoeudBin droit) {
		this.droit = droit;
	}
	
	public char getEtiquette() {
		return etiquette;
	}
	
	public void setEtiquette(char etiquette) {
		this.etiquette = etiquette;
	}

	public char getFinMot() {
		return finMot;
	}

	public void setFinMot(char finMot) {
		this.finMot = finMot;
	}
	
	
	
}
