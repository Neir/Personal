package Affichage;

import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

import AffichageBriandais.NoeudBinSwing;
import BriandaisTree.TreeBriandais;
import TrieHybride.TrieHybride;

public class TreePanel extends JPanel {
	private static final long serialVersionUID = 1L;
	private TrieHybride th;
	private TreeBriandais test;

	public TreePanel(TrieHybride th){
		this.th = th;
		this.setSize(1200, 800);
	}
	
	public TreePanel(TreeBriandais th){
		this.test = th;
		this.setSize(1200, 800);
	}
	
	public void paintComponent(Graphics g){
	 	NoeudSwing nds = new NoeudSwing(th.getRacine());
		nds.print(this.getWidth()/2, 30, g, 1);
	}
	
	public static void main(String[] args){
		JFrame fenetre = new JFrame();
		fenetre.setVisible(true);
		fenetre.setSize(1200, 800);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		TrieHybride th = new TrieHybride();
		th.ajoutPhrase("A quel genial professeur de dactylographie "
				+ "sommes nous redevable de la superbe phrase ci dessous :"
				+ "un modele du genre que toute dactylo connait par coeur "
				+ "puisque elle fait appel a chacune des touches du clavier "
				+ "de la machine a ecrire.");
				
	fenetre.setContentPane(new TreePanel(th));
		
	}
}
