package Affichage;

import java.awt.Color;
import java.awt.Graphics;

import TrieHybride.Noeud;

public class NoeudSwing{
	private Noeud nd;
	
	public NoeudSwing(Noeud nd) {
		super();
		this.nd = nd;
	}
	
	public void print(int x, int y, Graphics g, double size_coef){
		int size = (int) (20*size_coef);
		int marge = (int) (5*size_coef);
		//if(nd.getId()!=-1) g.setColor(Color.RED);
		g.drawOval(x, y, size, size);
		//char []tmp = { nd.getEtiquette()};//, Integer.toString(nd.getId()).charAt(0) };
		//g.drawChars(tmp, 0, marge*2, x+marge, y+marge);
		
		if(nd.getId()!=-1){
			g.setColor(Color.BLUE);
			g.drawString(nd.getEtiquette()+","+nd.getId(), x+marge/2, y+size*2/3);
			g.setColor(Color.BLACK);
		} else
			g.drawString(" "+nd.getEtiquette(), x+marge/2, y+size*2/3);
		
		// Branche des noeuds fils :
		int newX = x+size/2;
		int newY = y+size;
		int nextXG = (size)*nd.getInf().getLargeurTotal();
		int nextXD = (size)*nd.getSup().getLargeurTotal();
		//int pas_nextX = (size)*((nd.hauteur()+1)/2*nd.hauteur())/16;
		
		Noeud fils;
		NoeudSwing filsSwing;
		//*
		if(!(fils = nd.getInf()).estNil()){
			g.drawLine(newX, newY, newX-nextXG, newY+size); // inf
			filsSwing = new NoeudSwing(fils);
			filsSwing.print(newX-nextXG-marge*2, newY+size, g, size_coef);
		}
		if(!(fils = nd.getEq()).estNil()){
			g.drawLine(newX, newY, newX, newY+size); // eq
			filsSwing = new NoeudSwing(fils);
			filsSwing.print(newX-marge*2, newY+size, g, size_coef);
		}
		if(!(fils = nd.getSup()).estNil()){
			g.drawLine(newX, newY, newX+nextXD, newY+size); // sup
			filsSwing = new NoeudSwing(fils);
			filsSwing.print(newX+nextXD-marge*2, newY+size, g, size_coef);
		}
		//*/
	}
}
